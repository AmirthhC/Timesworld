$(function() {

    var filterList = {

        init: function() {

            $('#gallery').mixItUp({
                selectors: {
                    target: '.gallery-item',
                    filter: '.filter'
                },
                load: {
                    filter: '.drunch, .food, .iftar, .shisha, .breakfast, .cocktails, .food'
                }
            });

        }

    };


    filterList.init();

});